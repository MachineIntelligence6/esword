import { PrismaClient } from "@prisma/client";

const basePrisma = new PrismaClient()

const db = basePrisma.$extends(({

}))


export default db;