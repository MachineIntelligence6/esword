
import { Session } from "next-auth"


type Props = {
    session: Session
}

