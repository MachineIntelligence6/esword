


export default function NotFound() {
    return (
        <div className="w-full h-[500px] flex items-center justify-center">
            <div className="text-center">
                <h4 className="text-lg font-semibold">Author not found.</h4>
            </div>
        </div>
    )
}
