



const defaults = {
    PER_PAGE_ITEMS: 20
}

export default defaults;

